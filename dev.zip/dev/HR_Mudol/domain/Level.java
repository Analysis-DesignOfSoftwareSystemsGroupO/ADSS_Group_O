package HR_Mudol.domain;

public enum Level {
    HRManager,
    shiftManager,
    regularEmp
}
