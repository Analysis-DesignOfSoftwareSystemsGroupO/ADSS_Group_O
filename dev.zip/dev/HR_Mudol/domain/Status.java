package HR_Mudol.domain;

public enum Status
{
    Empty,
    Problem,
    Full;
}
