package HR_Mudol.domain;

public enum ShiftType {
    MORNING,
    EVENING
}
